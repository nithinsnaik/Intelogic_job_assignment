How to run this User Registration & Login  Project

1.install Xampp software and start the Apache and MySql server

2. Download the  zip file

3. Extract the file and copy intelogic folder into C:\xampp\htdocs 

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name userdetail

6. Import userdetail.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/intelogic


