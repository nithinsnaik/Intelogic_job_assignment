<?php

require('connection.php');
session_start();

#FOR login
if(isset($_POST['login']))
{
    $query="SELECT * FROM `reg_users` WHERE `email`='$_POST[email_username]' OR `username`='$_POST[email_username]'";
    $result=mysqli_query($con,$query);

    if($result)
    {
        if(mysqli_num_rows($result)==1)
        {
            $result_featch=mysqli_fetch_assoc($result);
            if(password_verify($_POST['password'],$result_featch['password']))
            {
            $_SESSION['logged_in']=true;
            $_SESSION['username']=$result_featch['username'];
            echo"<script> window.location.href='details.php'</script>";
            //header("location:details.php");
          
            }
            else
            {
            echo"
            <script>
                alert('Incorrect Password');
                window.location.href='index.php';
            </script>
            ";

            }
        }
        else
        {
            echo"
            <script>
                alert('Username or Email not Registred');
                window.location.href='index.php';
            </script>
            ";
        }
    }
    else
    {
        echo"
        <script>
            alert('Cannot run query');
            window.location.href='index.php';
        </script>
        ";
    }
}

#For registration

if(isset($_POST['register']))
{
 $user_exist_query="SELECT * FROM `reg_users` WHERE `username`='$_POST[username]' OR `email`='$_POST[email]'";
 $result=mysqli_query($con,$user_exist_query);

 if($result)
 {
    if(mysqli_num_rows($result)>0) #it will be executed if user or email already registred
    {
        #if any user has already registred
        $result_featch=mysqli_fetch_assoc($result);
        if($result_featch['username']==$_POST['username'])
        {   
            #error for user already registred
            echo"
                <script>
                    alert('$result_featch[username]- Username already registred');
                    window.location.href='index.php';
                </script>
            ";
        }
        else
        {
            #error for email already registred
            echo"
                <script>
                    alert('$result_featch[email]- email already registred');
                    window.location.href='index.php';
                </script>
            ";
        }
    }
    else #it will be executed if no one taken username or email before
    {
        $password=password_hash($_POST['password'],PASSWORD_BCRYPT);
        $query="INSERT INTO `reg_users`(`full_name`, `username`, `email`, `password`) VALUES ('$_POST[fullname]','$_POST[username]','$_POST[email]','$password')";
        if(mysqli_query($con,$query))
        {
             #if data inserted sucessfully
            echo"
                <script>
                    alert('Registration sucessfully');
                    window.location.href='index.php'; 
                </script>
            ";
        }
        else
        {
            #if data cannot be inserted
            echo"
                <script>
                    alert('Registration is unsucessfull');
                    window.location.href='index.php';
                </script>
            ";
        }
    }

 }
 else
 {
    echo"
        <script>
            alert('Cannot run query');
            window.location.href='index.php';
        </script>
    ";
 }
 
}


?>