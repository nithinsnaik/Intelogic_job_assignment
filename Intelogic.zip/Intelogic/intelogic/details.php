<?php 
require('connection.php'); 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User - Login and Register</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <img src="wellcome.jpg" height="225" width="1585"></img>
  
  <header>
    <h2>Nithin WEBDEV</h2>
    <nav>
      <a href="http://localhost/intelogic/details.php">HOME</a>
      <a href="#">ABOUT</a>
    </nav>
    <?php

     if(isset($_SESSION['logged_in'])&& $_SESSION['logged_in']==true)
     {
      echo"<div class='user'>
      <a href='logout.php'>LOG OUT</a>
      </div>
      ";
     }
     else
     {
     echo"
     <div class='sign-in-up'>
      <button type='button' onclick='popup('login-popup')'>LOGIN</button>
      <button type='button' onclick='popup('register-popup')'>REGISTER</button>
    </div>
     ";
     }
    ?>
  </header>

  <?php
  if(isset($_SESSION['logged_in'])&& $_SESSION['logged_in']==true)
  {
   echo"<h1 style='text-align: center; margin-top: 250px; color: forestgreen '>Hello  $_SESSION[username] wellcome to this web page</h1>";
  }
  ?>

</body>
</html>